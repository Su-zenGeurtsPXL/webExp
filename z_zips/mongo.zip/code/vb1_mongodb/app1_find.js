const dotenv=require("dotenv");
dotenv.config();
const {MongoClient, ObjectId} = require("mongodb");
const PORT = process.env.PORT;
const DATABASE_CONNECTION = process.env.DATABASE_CONNECTION ;

const client = new MongoClient(DATABASE_CONNECTION);

async function run() {
    try {
        await client.connect();
        const database = client.db();
        let persons = await database.collection( "persons" ).find( { name : /^[tT]/ });
        while(await persons.hasNext()){
            let person = await persons.next();
            console.log(person);
        }
    } finally {
        await client.close();
    }
}

async function cleanup (event) { 
    console.log("Bye!");
    await client.close(); 
    await process.exit(); 
}

run().catch( (err) => {console.log( err.stack );} );
process.on("SIGINT", cleanup);
process.on("SIGTERM", cleanup);


