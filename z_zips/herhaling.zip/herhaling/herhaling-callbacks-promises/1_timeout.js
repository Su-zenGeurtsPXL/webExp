console.log('start');
setTimeout(() => {
    console.log('waiting 1 sec');
}, 1000);
console.log('done');