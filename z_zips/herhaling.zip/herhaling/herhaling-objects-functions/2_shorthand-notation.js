/*
let id = 1;
let person = { id, name:'tim' }; // ipv let person = { id:id, name: 'tim' };
console.log(person);
*/

/*
let id = 1;
let name = 'tim';
let person = {id, name};  // ipv let person = {id: id, name: name};
console.log(person);
*/