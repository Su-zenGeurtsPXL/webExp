const {uppercase, lowercase} = require('./text');
console.log( uppercase('Ok'));
console.log( lowercase('Ok'));