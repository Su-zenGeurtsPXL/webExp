const uppercase = (text) => text.toUpperCase();
const lowercase = (text) => text.toLowerCase();
module.exports = {lowercase, uppercase};        // <== Shorthand notation

/*
module.exports = geëxporteerde vanuit de module
krijgt hier een nieuw object met velden lowercase en uppercase als waarde
*/