'use strict'
const textUtils = require('./text');        // <== 'textUtils' werd aangemaakt, dit object kan gebruikt worden
let result = textUtils.uppercase('test');
console.log(result);