'use strict'
module.exports.uppercase = (text) => text.toUpperCase();
module.exports.lowercase = (text) => text.toLowerCase();


/*
module.exports = geëxporteerde vanuit de module
default een lege object literal, aan dit object worden hier velden uppercase en
lowercase toegevoegd
*/