'use strict'
const {uppercase, lowercase} = require('./text'); // Import door middel van destructuring, geen bovenliggend object
let result = uppercase('test');
console.log(result);