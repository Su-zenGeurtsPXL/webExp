let printer = require('./util/printer.js')('Niek');
printer.printUppercase();
